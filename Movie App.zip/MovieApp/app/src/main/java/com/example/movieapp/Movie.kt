package com.example.movieapp

data class Movie(val title: String,val horizontalMovies: List<Int>)

